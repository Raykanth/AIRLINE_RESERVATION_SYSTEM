from django.contrib import admin
from .models import login
# Register your models here.
 
admin.site.register(login)