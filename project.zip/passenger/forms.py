from django import forms

class FORMS(forms.Form):
    username=forms.CharField()
    password=forms.CharField()
    email=forms.CharField()
    phonenumber=forms.IntegerField()
    number=forms.IntegerField()