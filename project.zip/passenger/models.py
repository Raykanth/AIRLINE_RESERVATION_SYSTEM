from django.db import models
from django.core.validators import MaxLengthValidator,MaxValueValidator,MinValueValidator
# Create your models here.

class login(models.Model):
    username=models.CharField(max_length=30)
    password=models.CharField(max_length=30)
    email=models.CharField(max_length=30)
    phonenumber=models.IntegerField()
    number=models.IntegerField(
        validators=[MinValueValidator(1),MaxValueValidator(10)])
    
    def __str__(self):
        return f"{self.username}  -  {self.password}  -  {self.email}"
