from django.urls import path
from . import views

urlpatterns=[
    path("",views.main,name="main"),
    path("administrator",views.administrator,name="Admin"),
    path("administrator/<int:id>",views.adminlogin,name="adminlogin"),
    path("passenger",views.customer,name="customer"),
    path("passenger/reservation",views.reservation,name="reservation"),
    path("passenger/cancellation",views.cancellation,name="cancellation"),
    path("passenger/checkdetails",views.checkdetails,name="checking"),
    path("passenger/flightinfo",views.flightinfo,name="flightinfo"),
    path("passenger/pnrstatus",views.pnrinfo,name="pnrinfo")
]