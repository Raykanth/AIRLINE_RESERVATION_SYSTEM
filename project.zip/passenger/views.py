from django.http.response import HttpResponseRedirect
from django.shortcuts import render
from .models import login
from .forms import FORMS
# Create your views here.

def main(request):
    if request.method=="POST":
        form=FORMS(request.POST)
        if form.is_valid():
            a=login(
                username=form.cleaned_data["username"],
                password=form.cleaned_data["password"],
                email=form.cleaned_data["email"],
                phonenumber=form.cleaned_data["phonenumber"],
                number=form.cleaned_data["number"])
            a.save()
            return HttpResponseRedirect("/administrator")
    form=FORMS()
    return render(request,"passenger/one.html",{
        "form":form
    })
def administrator(request):
    id_paw_f=login.objects.all()
    return render(request,"passenger/Admin.html",{
        "id_paw":id_paw_f
    })
def adminlogin(request,id):
    id_paw_f=login.objects.get(pk=id)
    return render(request,"passenger/login.html",{
        "id_paw":id_paw_f
    })
def customer(request):
    return render(request,"passenger/customer.html")
def reservation(request):
    return render(request,"passenger/reservation.html")
def cancellation(request):
    return render(request,"passenger/cancellation.html")
def checkdetails(request):
    return render(request,"passenger/checkdetails.html")
def flightinfo(request):
    return render(request,"passenger/flightinfo.html")
def pnrinfo(request):
    return render(request,"passenger/pnrinfo.html")